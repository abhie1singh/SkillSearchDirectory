'use strict';

// Declare app level module which depends on views, and components
var myApp = angular.module('myApp', [
  'ngRoute',
  'ui.router',
  'myApp.view1',
  'myApp.view2',
  'myApp.version',
  'ngAvatar'
]).
config(['$locationProvider', '$routeProvider','$stateProvider', '$urlRouterProvider', function($locationProvider, $routeProvider, $stateProvider ,$urlRouterProvider) {
  $locationProvider.hashPrefix('!');

  $urlRouterProvider.otherwise("/login");
  $stateProvider
  	.state('home',{
  		url: '/home',
  		templateUrl: 'pages/home.html'
  	})
  	.state('login',{
  		url:'/login',
  		templateUrl: 'pages/login.html'
  	})
  	.state('logout',{
  		url:'/logout',
  		template: '<p> You have been successfully logged out. </p>'
  	})
  	.state('register',{
  		url:'/register',
  		templateUrl: 'pages/createProfile.html'
  	})  	
  	.state('editProfile',{
  		url:'/editProfile',
  		templateUrl: 'pages/editprofile.html'
  	})
  	.state('viewProfile',{
  		url: '/viewProfile/:userId',
  		templateUrl: 'pages/user.html'
  	})
  	.state('viewProject',{
  		url:'/viewProject/:projectId',
  		templateUrl: 'pages/project.html'
  	});
}]);
