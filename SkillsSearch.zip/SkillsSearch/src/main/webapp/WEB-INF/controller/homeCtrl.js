myApp.controller('homeCtrl',function($scope){

	$scope.addGuidance = function($index,post){
		$scope.posts[$index].guidanceCount++;
	}

	$scope.addHelp = function($index,post){
		$scope.posts[$index].helpCount++;
	}


	$scope.notifications = [
	{
		"id" : 0,
		"guruName": "Raheed",
		"guruId": 1,
		"menteeName" : "Josh",
		"menteeId": 2,
		"helpSubject" : "Configuring Websphere for UAT environment",
		"teamName" : "GTI: Team Example"
	},
	{
		"id" : 1,
		"guruName": "Zack",
		"guruId": 1,
		"menteeName" : "Donald",
		"menteeId": 2,
		"helpSubject" : "Creating DAO Layer for Apache Spark",
		"teamName" : "GIM: Regulatory Compliance"
	},
	{
		"id" : 2,
		"guruName": "Aurva",
		"guruId": 1,
		"menteeName" : "Raheed",
		"menteeId": 2,
		"helpSubject" : "Choosing an Android phone",
		"teamName" : "GIM: Regulatory Compliance"
	}

	];


	$scope.addPost = function(){
		$scope.posts.unshift(
    {
      "id": 0,
      "name": "Adam Carter",
      "text": $scope.postContent,
      "work": "Unilogic",
      "email": "adam.carter@unilogic.com",
      "dob": "24/11/1978",
      "address": "83 Warner Street",
      "guidanceCount": 0,
      "helpCount": 1,
      "city": "Boston",
      "optedin": true
    }


			);

		$scope.postContent = "";
	}

	$scope.posts = [
    {
      "id": 0,
      "name": "Adam Carter",
      "text": "this is a test post",
      "work": "Unilogic",
      "email": "adam.carter@unilogic.com",
      "dob": "24/11/1978",
      "address": "83 Warner Street",
      "guidanceCount": 9,
      "helpCount": 10,
      "city": "Boston",
      "optedin": true
    },
    {
      "id": 1,
      "name": "Leanne Brier",
      "text": "this is a test post2",
      "work": "Connic",
      "email": "leanne.brier@connic.org",
      "dob": "13/05/1987",
      "address": "9 Coleman Avenue",
      "guidanceCount": 10,
      "helpCount": 5,
      "city": "Toronto",
      "optedin": false
    },
    {
      "id": 1,
      "name": "Leanne Brier",
      "text": "this is a test post2",
      "work": "Connic",
      "email": "leanne.brier@connic.org",
      "dob": "13/05/1987",
      "address": "9 Coleman Avenue",
      "guidanceCount": 2,
      "helpCount": 10,
      "city": "Toronto",
      "optedin": false
    },
    {
      "id": 1,
      "name": "Leanne Brier",
      "text": "this is a test post2",
      "work": "Connic",
      "email": "leanne.brier@connic.org",
      "dob": "13/05/1987",
      "address": "9 Coleman Avenue",
      "guidanceCount": 12,
      "helpCount": 100,
      "city": "Toronto",
      "optedin": false
    }

  ];
	$scope.name = "Raheed";
});