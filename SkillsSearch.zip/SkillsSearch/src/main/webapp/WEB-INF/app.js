'use strict';

// Declare app level module which depends on views, and components
var myApp = angular.module('myApp', [
  'ngRoute',
  'ui.router',
  'myApp.view1',
  'myApp.view2',
  'myApp.version'
]).
config(['$locationProvider', '$routeProvider','$stateProvider', '$urlRouterProvider', function($locationProvider, $routeProvider, $stateProvider ,$urlRouterProvider) {
  $locationProvider.hashPrefix('!');

  $urlRouterProvider.otherwise("/home");
  $stateProvider
  	.state('home',{
  		url: '/home',
  		templateUrl: 'pages/home.html'
  	})
  	.state('login',{
  		url:'/login',
  		templateUrl: 'view2/view2.html'
  	})
  	.state('editProfile',{
  		url:'/editProfile',
  		templateUrl: 'pages/editprofile.html'
  	})
  	.state('viewProfile',{
  		url: '/viewProfile/:userId',
  		templateUrl: 'pages/user.html'
  	})
  	.state('viewProject',{
  		url:'/viewProject/:projectId',
  		templateUrl: 'pages/project.html'
  	});
}]);
