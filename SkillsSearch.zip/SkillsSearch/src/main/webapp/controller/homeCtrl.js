myApp.controller('homeCtrl',function($scope,$rootScope,$http,$state){
	console.log($rootScope.user);
	
	if($rootScope.user == null){
		$state.go('login');
	}
	$scope.addGuidance = function($index,post){
		$scope.posts[$index].guidanceCount++;
	}

	$scope.addHelp = function($index,post){
		$scope.posts[$index].helpCount++;
	}
	
	var params = {
			requester : $rootScope.user.userSid
	}
	$http.post('/Help/HelpByRequester/', params)
	.then(function(resp){
		$scope.posts= resp.data;
	});



	$scope.nameInitial = "A";

	$scope.notifications = [
	{
		"id" : 0,
		"guruName": "Raheed",
		"guruId": 1,
		"menteeName" : "Josh",
		"menteeId": 2,
		"helpSubject" : "Configuring Websphere for UAT environment",
		"teamName" : "GTI: Team Example"
	},
	{
		"id" : 1,
		"guruName": "Zack",
		"guruId": 1,
		"menteeName" : "Donald",
		"menteeId": 2,
		"helpSubject" : "Creating DAO Layer for Apache Spark",
		"teamName" : "GIM: Regulatory Compliance"
	},
	{
		"id" : 2,
		"guruName": "Aurva",
		"guruId": 1,
		"menteeName" : "Raheed",
		"menteeId": 2,
		"helpSubject" : "Choosing an Android phone",
		"teamName" : "GIM: Regulatory Compliance"
	}

	];


	$scope.addPost = function(){
		var params = {
				requester : $rootScope.user.userSid,
				comment : $scope.postContent
		}
		if($scope.postContent != null){
			$http.post('/Help/CreateHelp', params)
				.then(function(response){
					$http.post('/Help/HelpByRequester/', params)
						.then(function(resp){
							$scope.posts= resp.data;
						});
				});

		}
		// $scope.posts.unshift(
  //   {
  //     "id": 0,
  //     "name": "Adam Carter",
  //     "text": $scope.postContent,
  //     "work": "Unilogic",
  //     "email": "adam.carter@unilogic.com",
  //     "dob": "24/11/1978",
  //     "address": "83 Warner Street",
  //     "guidanceCount": 0,
  //     "helpCount": 1,
  //     "city": "Boston",
  //     "optedin": true
  //   });

		$scope.postContent = "";
	}

	$scope.posts = [];
});