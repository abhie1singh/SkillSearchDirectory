myApp.controller('loginCtrl', function($scope,$rootScope,$state,$http){
	$scope.login = function(){
		var params = {
			email: $scope.email,
			password: $scope.password
		}
		$http.post('/user/CheckLogin',params)
			.success(function(response){
				if(!response.userId){
					alert('Incorrect credentials.  Please try to login again.');
					$scope.password="";
					console.log(params);
				}else{
					$rootScope.loggedIn = true;
					$rootScope.user = response;
					$state.go('home');					
				}

				$rootScope.loggedIn = true;
//				$rootScope.$digest();



			})
			.error(function(err){
							// $rootScope.loggedIn = true;
							// $rootScope.user = $scope.userInfo;
							// $state.go('home');
				alert('Incorrect credentials.  Please try to login again.');
				console.log(params);
			});
	}

	// $scope.userInfo = {
	//   "userId": 1,
	//   "createdBy": "o509773",
	//   "createdDate": 1475421045000,
	//   "email": "abhimanyu.x.singh@jpmorgan.com",
	//   "password": "abhie",
	//   "updatedBy": "o509773",
	//   "updatedDate": 1475421045000,
	//   "userSid": "o509773",
	//   "userProfile": {
	//     "iduserProfile": 1,
	//     "createdBy": "o509773",
	//     "createdDate": 1475421045000,
	//     "firstName": "Abhie",
	//     "isOoo": "N",
	//     "lastName": "Singh",
	//     "locationId": 2,
	//     "updatedBy": "o509773",
	//     "updatedDate": 1475421045000,
	//     "userId": 2,
	//     "userSid": "o509773"
	//   },
	//   "location": {
	//     "locationId": 2,
	//     "address1": "4 New York Plaza",
	//     "address2": null,
	//     "city": "New York",
	//     "country": "US",
	//     "createdBy": "o509773",
	//     "createdDate": 1475421045000,
	//     "state": "New York",
	//     "updatedBy": "o509773",
	//     "updatedDate": 1475421045000,
	//     "zip": "41141"
	//   }
	// };

});