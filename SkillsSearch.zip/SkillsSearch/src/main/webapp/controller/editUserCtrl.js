myApp.controller('editUserCtrl', function($scope,$http){
	// $http.get('/getUserInfo/{{}}')
	// 	.then(function(response){
	// 		$scope.userInfo = response.data;
	// 	});

	$scope.userInfo = 
{
  "userId": 1,
  "createdBy": "o509773",
  "createdDate": 1475421045000,
  "email": "abhimanyu.x.singh@jpmorgan.com",
  "password": "abhie",
  "updatedBy": "o509773",
  "updatedDate": 1475421045000,
  "userSid": "o509773",
  "userProfile": {
    "iduserProfile": 1,
    "createdBy": "o509773",
    "createdDate": 1475421045000,
    "firstName": "Abhie",
    "isOoo": "N",
    "lastName": "Singh",
    "locationId": 2,
    "updatedBy": "o509773",
    "updatedDate": 1475421045000,
    "userId": 2,
    "userSid": "o509773"
  },
  "location": {
    "locationId": 2,
    "address1": "4 New York Plaza",
    "address2": null,
    "city": "New York",
    "country": "US",
    "createdBy": "o509773",
    "createdDate": 1475421045000,
    "state": "New York",
    "updatedBy": "o509773",
    "updatedDate": 1475421045000,
    "zip": "41141"
  }
}
	console.log($scope.userInfo);

});