myApp.controller('userCtrl', function($scope){
	
});