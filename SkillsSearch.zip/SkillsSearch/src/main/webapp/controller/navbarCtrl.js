myApp.controller('navbarCtrl',function($scope,$rootScope){
	$scope.isLoggedIn = function(){
		if($rootScope.user == null){
			return false;
		}
	}
	$scope.logout = function(){
		$rootScope.isLoggedIn = false;
		$rootScope.user= null;
	}

});