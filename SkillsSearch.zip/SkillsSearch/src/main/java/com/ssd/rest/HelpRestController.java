/**
 * 
 */
package com.ssd.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssd.entity.Help;
import com.ssd.service.HelpService;

/**
 * @author abhimanyu
 *
 */
@RestController
@RequestMapping(value = "/Help")
public class HelpRestController {

	@Autowired
	private HelpService helpService;
	
	@RequestMapping(value = "/FindAll", method = RequestMethod.GET)
	public ResponseEntity<List<Help>> findAllHelpRequests() {
		List<Help> users = helpService.findAll();
		if(users.isEmpty()){
			return new ResponseEntity<List<Help>>(HttpStatus.OK);//You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Help>>(users, HttpStatus.OK);
	}
	
	@RequestMapping(value = "CreateHelp", method = RequestMethod.POST)
	public ResponseEntity<Help> createHelp(@RequestBody Help help) {
		helpService.createHelp(help);
		return new ResponseEntity<Help>(help, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/HelpByRequester", method = RequestMethod.POST)
	public ResponseEntity<List<Help>> findHelpByRequester(@RequestBody Help help) {
		List<Help> helpList = helpService.findHelpByRequester(help.getRequester());
		if(helpList.isEmpty()){
			return new ResponseEntity<List<Help>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Help>>(helpList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/HelpByProvider/{provider}", method = RequestMethod.POST)
	public ResponseEntity<List<Help>> findHelpByProvider(@PathVariable("provider") final String provider) {
		List<Help> helpList = helpService.findHelpByRequester(provider);
		if(helpList.isEmpty()){
			return new ResponseEntity<List<Help>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Help>>(helpList, HttpStatus.OK);
	}
}
