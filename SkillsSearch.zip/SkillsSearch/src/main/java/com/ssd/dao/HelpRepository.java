/**
 * 
 */
package com.ssd.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ssd.entity.Help;

/**
 * @author abhimanyu
 *
 */
public interface HelpRepository extends JpaRepository<Help, String>{
	List<Help> findHelpByRequester(String requester);
	List<Help> findHelpByProvider(String provider);
}
