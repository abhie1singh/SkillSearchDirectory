/**
 * 
 */
package com.ssd.service;

import java.util.List;

import com.ssd.entity.Help;

/**
 * @author abhimanyu
 *
 */
public interface HelpService {

	List<Help> findAll();
	
	Help findHelpByIdHelp();
	
	List<Help> findHelpByProvider(String provider);
	
	List<Help> findHelpByRequester(String requester);
	
	Help findHelpByRequesterAndIsApproved();
	
	Help findHelpByProviderAndIsHelping();

	void createHelp(Help help);
	
}
