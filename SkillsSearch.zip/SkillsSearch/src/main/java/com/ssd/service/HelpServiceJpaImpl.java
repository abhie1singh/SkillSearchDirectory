/**
 * 
 */
package com.ssd.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssd.dao.HelpRepository;
import com.ssd.dao.UserProfileRepository;
import com.ssd.dao.UserRepository;
import com.ssd.entity.Help;
import com.ssd.entity.User;

/**
 * @author abhimanyu
 *
 */
@Service
public class HelpServiceJpaImpl implements HelpService {

	@Autowired
    private HelpRepository helpRepository;
	
	@Autowired
	private UserProfileRepository userProfileRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	/* (non-Javadoc)
	 * @see com.ssd.service.HelpService#findAll()
	 */
	@Override
	public List<Help> findAll() {
		// TODO Auto-generated method stub
		return helpRepository.findAll();
	}

	/* (non-Javadoc)
	 * @see com.ssd.service.HelpService#findHelpByIdHelp()
	 */
	@Override
	public Help findHelpByIdHelp() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ssd.service.HelpService#findHelpByProvider()
	 */
	@Override
	public List<Help> findHelpByProvider(String provider) {
		
		List<Help> helpList = helpRepository.findHelpByProvider(provider);
		Iterator<Help> itr = null;
		if(null != helpList && helpList.size() > 0){
			itr = helpList.iterator();
			if(null != itr){
				while(itr.hasNext()){
					Help help = itr.next();
					User user = null;
					if(null != help){
						user = userRepository.findByUserSid(help.getProvider());
						if(null != user){
							help.setProviderUser(user);
						}
						
						user = userRepository.findByUserSid(help.getRequester());
						if(null != user){
							help.setRequesterUser(user);
						}
					}
				}
			}
		}
		return helpList;
	}

	/* (non-Javadoc)
	 * @see com.ssd.service.HelpService#findHelpByRequester()
	 */
	@Override
	public List<Help> findHelpByRequester(String requester) {
		
		List<Help> helpList = helpRepository.findHelpByRequester(requester);
		Iterator<Help> itr = null;
		if(null != helpList && helpList.size() > 0){
			itr = helpList.iterator();
			if(null != itr){
				while(itr.hasNext()){
					Help help = itr.next();
					User user = null;
					if(null != help){
						user = userRepository.findByUserSid(help.getProvider());
						if(null != user){
							help.setProviderUser(user);
						}
						
						user = userRepository.findByUserSid(help.getRequester());
						if(null != user){
							help.setRequesterUser(user);
						}
					}
				}
			}
		}
		return helpList;
	}

	/* (non-Javadoc)
	 * @see com.ssd.service.HelpService#findHelpByRequesterAndIsApproved()
	 */
	@Override
	public Help findHelpByRequesterAndIsApproved() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ssd.service.HelpService#findHelpByProviderAndIsHelping()
	 */
	@Override
	public Help findHelpByProviderAndIsHelping() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createHelp(Help help) {
		if(null != help){
			helpRepository.save(help);
		}
		
	}

}
